﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// 测试对象
    /// </summary>
    public class Demo
    {
        /// <summary>
        /// 测试id
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 测试标题
        /// </summary>
        public string title { get; set; }

    }
}
