﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    /// <summary>
    /// 全局静态变量
    /// </summary>
    public class GlobalVar
    {
        /// <summary>
        /// UDP要发送数据的文件名
        /// </summary>
        public const string UDP_Send_Data_FileName = "udp_send_data";
    }
}
