﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Model
{
    /// <summary>
    /// 演示多线程子方法所需的参数
    /// </summary>
    public class TestThreadParams : BaseMultiThreadParams
    {
        /// <summary>
        /// 参数1
        /// </summary>
        public string Key { get; set; }
    }
}
