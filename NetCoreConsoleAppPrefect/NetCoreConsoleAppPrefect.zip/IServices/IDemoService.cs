﻿using System.Threading.Tasks;

namespace $safeprojectname$.IServices
{
    public interface IDemoService : IBaseBusinessService
    {
        Task Test();
    }
}
