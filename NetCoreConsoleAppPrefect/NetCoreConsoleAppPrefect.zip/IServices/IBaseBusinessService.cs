﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.IServices
{
    /// <summary>
    /// 非数据库相关的业务基类
    /// </summary>
    public interface IBaseBusinessService : IBatchDIServicesTag
    {

    }
}
